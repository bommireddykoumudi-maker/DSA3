class RouteOptimizer:
    """Nearest Neighbor heuristic on a weighted adjacency-list graph."""

    def __init__(self, graph, average_speed_kmh=40):
        self.graph = graph
        self.average_speed_kmh = float(average_speed_kmh)

    @staticmethod
    def to_minutes(value, default=0):
        try:
            h, m = str(value).split(":")[:2]
            return int(h) * 60 + int(m)
        except (ValueError, TypeError):
            return default

    @staticmethod
    def to_hhmm(minutes):
        minutes = int(round(minutes)) % (24 * 60)
        return f"{minutes // 60:02d}:{minutes % 60:02d}"

    def nearest_neighbor(self, start, deliveries, dispatch_minutes=9 * 60):
        if start not in self.graph:
            return [start, start], 0, 0, [], [], None

        grouped = {}
        for delivery in deliveries:
            grouped.setdefault(delivery["location"], []).append(delivery)

        unvisited = set(grouped)
        current = start
        route = [start]
        total_distance = 0.0
        current_minutes = float(dispatch_minutes)
        timeline = []
        violations = []

        while unvisited:
            candidates = []

            for location in unvisited:
                edge_distance = self.graph.get(current, {}).get(location)
                if edge_distance is None:
                    continue

                travel_minutes = edge_distance / self.average_speed_kmh * 60
                arrival = current_minutes + travel_minutes
                items = grouped[location]
                starts = [self.to_minutes(d.get("time_start", "09:00"), 9 * 60) for d in items]
                ends = [self.to_minutes(d.get("time_end", "18:00"), 18 * 60) for d in items]
                window_start = max(starts)
                window_end = min(ends)
                overlap_ok = window_start <= window_end
                service_start = max(arrival, window_start)
                feasible = overlap_ok and service_start <= window_end

                candidates.append((
                    0 if feasible else 1,
                    edge_distance,
                    window_end,
                    location,
                    arrival,
                    window_start,
                    overlap_ok,
                ))

            if not candidates:
                break

            # Prefer a time-window-feasible stop, then the nearest stop.
            candidates.sort(key=lambda item: (item[0], item[1], item[2], item[3]))
            _, distance, window_end, location, arrival, window_start, overlap_ok = candidates[0]

            current_minutes = max(arrival, window_start)
            on_time = overlap_ok and current_minutes <= window_end
            if not on_time:
                violations.append(location)

            total_distance += distance
            route.append(location)
            timeline.append({
                "location": location,
                "arrival": self.to_hhmm(current_minutes),
                "window": f"{self.to_hhmm(window_start)}–{self.to_hhmm(window_end)}",
                "on_time": on_time,
            })

            current = location
            unvisited.remove(location)

        if current in self.graph and start in self.graph[current]:
            return_distance = self.graph[current][start]
            total_distance += return_distance
            current_minutes += return_distance / self.average_speed_kmh * 60
            route.append(start)

        elapsed_minutes = max(0, current_minutes - dispatch_minutes)
        completion_clock = self.to_hhmm(current_minutes)
        return (
            route,
            round(total_distance, 2),
            round(elapsed_minutes),
            timeline,
            sorted(set(violations)),
            completion_clock,
        )

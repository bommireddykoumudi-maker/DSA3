from flask import Flask, jsonify, request
from flask_cors import CORS

from graph import delivery_graph
from optimizer import RouteOptimizer
from vehicle import Vehicle, VehicleAssignment
from constraints import ConstraintChecker
from performance import PerformanceAnalyzer

app = Flask(__name__)
CORS(app)

DEFAULT_DELIVERIES = [
    {"location": "Hafeezpet", "weight": 20, "time_start": "09:00", "time_end": "11:00"},
    {"location": "Miyapur", "weight": 30, "time_start": "10:00", "time_end": "12:00"},
    {"location": "Kondapur", "weight": 25, "time_start": "11:00", "time_end": "13:00"},
    {"location": "Gachibowli", "weight": 35, "time_start": "12:00", "time_end": "14:00"},
]

DEFAULT_VEHICLES = [
    {"vehicle_id": "V-01", "capacity": 100},
    {"vehicle_id": "V-02", "capacity": 80},
]


def normalize_deliveries(raw):
    result = []
    valid_locations = set(delivery_graph.graph) - {"Warehouse"}
    for index, item in enumerate(raw or []):
        location = str(item.get("location", "")).strip()
        if location not in valid_locations:
            continue
        try:
            weight = float(item.get("weight", 0))
        except (TypeError, ValueError):
            continue
        if weight <= 0:
            continue
        result.append({
            "location": location,
            "weight": weight,
            "time_start": str(item.get("time_start", "09:00")),
            "time_end": str(item.get("time_end", "18:00")),
            "_index": index,
        })
    return result


def normalize_vehicles(raw):
    result = []
    for item in raw or []:
        vehicle_id = str(item.get("vehicle_id", "")).strip().upper()
        try:
            capacity = float(item.get("capacity", 0))
        except (TypeError, ValueError):
            continue
        if vehicle_id and capacity > 0:
            result.append({"vehicle_id": vehicle_id, "capacity": capacity})
    return result


def build_result(deliveries=None, vehicles_data=None):
    deliveries = normalize_deliveries(
        DEFAULT_DELIVERIES if deliveries is None else deliveries
    )
    vehicles_data = normalize_vehicles(
        DEFAULT_VEHICLES if vehicles_data is None else vehicles_data
    )

    vehicles = [Vehicle(v["vehicle_id"], v["capacity"]) for v in vehicles_data]
    unassigned = VehicleAssignment(vehicles).assign(deliveries)
    optimizer = RouteOptimizer(delivery_graph.graph, average_speed_kmh=40)
    checker = ConstraintChecker()

    vehicle_results = []
    total_distance = 0.0
    total_fuel = 0.0
    completion_times = []
    feasible_count = 0

    for vehicle in vehicles:
        route, distance, elapsed, timeline, violations, completion_clock = optimizer.nearest_neighbor(
            "Warehouse", vehicle.deliveries
        )
        checks = checker.validate(vehicle, route, violations)
        if checks["feasible"]:
            feasible_count += 1

        fuel = round(distance / 15, 2)
        total_distance += distance
        total_fuel += fuel
        completion_times.append(elapsed)

        vehicle_results.append({
            "vehicle_id": vehicle.vehicle_id,
            "capacity": round(vehicle.capacity, 2),
            "current_load": round(vehicle.total_load, 2),
            "deliveries": vehicle.deliveries,
            "route": route,
            "distance": round(distance, 2),
            "time_minutes": int(elapsed),
            "completion_time": completion_clock,
            "fuel_litres": fuel,
            "timeline": timeline,
            "time_violations": violations,
            "feasible": checks["feasible"],
            "checks": checks,
        })

    # A simple direct round-trip baseline. It is a reference metric, not an exact optimum.
    baseline = sum(
        delivery_graph.graph["Warehouse"][d["location"]] * 2
        for d in deliveries
    )
    analyzer = PerformanceAnalyzer(baseline, total_distance)
    saved, improvement = analyzer.result()

    total_deliveries = len(deliveries)
    assigned_count = total_deliveries - len(unassigned)
    assignment_rate = (assigned_count / total_deliveries * 100) if total_deliveries else 100
    vehicle_rate = (feasible_count / len(vehicles) * 100) if vehicles else 100
    constraint_satisfaction = round(min(assignment_rate, vehicle_rate), 2)

    # Vehicles operate in parallel, so completion time is the slowest vehicle route.
    estimated_completion_minutes = max(completion_times) if completion_times else 0

    return {
        "total_deliveries": total_deliveries,
        "active_vehicles": len(vehicles),
        "total_capacity": round(sum(v.capacity for v in vehicles), 2),
        "total_distance": round(total_distance, 2),
        "estimated_time_minutes": int(estimated_completion_minutes),
        "total_travel_minutes": int(sum(completion_times)),
        "estimated_fuel_litres": round(total_fuel, 2),
        "baseline_distance": round(baseline, 2),
        "distance_saved": saved,
        "improvement": improvement,
        "constraint_satisfaction": constraint_satisfaction,
        "assigned_count": assigned_count,
        "unassigned_count": len(unassigned),
        "unassigned": unassigned,
        "algorithm": "Nearest Neighbor Heuristic",
        "data_structure": "Weighted Graph (Adjacency List)",
        "average_speed_kmh": 40,
        "fuel_efficiency_kmpl": 15,
        "dispatch_time": "09:00",
        "vehicles": vehicle_results,
    }


@app.get("/")
def home():
    return jsonify({
        "project": "Delivery Route Optimizer",
        "status": "Backend is running",
        "engine": "Weighted Graph + Nearest Neighbor + Vehicle Constraints",
    })


@app.get("/api/graph")
def graph():
    return jsonify(delivery_graph.graph)


@app.route("/api/dashboard", methods=["GET", "POST"])
def dashboard():
    if request.method == "POST":
        data = request.get_json(silent=True) or {}
        return jsonify(build_result(data.get("deliveries"), data.get("vehicles")))
    return jsonify(build_result())


@app.post("/api/optimize")
def optimize():
    data = request.get_json(silent=True) or {}
    return jsonify(build_result(data.get("deliveries"), data.get("vehicles")))


if __name__ == "__main__":
    app.run(debug=True)

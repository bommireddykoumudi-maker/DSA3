class DeliveryGraph:
    """Weighted adjacency-list graph for the delivery network."""

    def __init__(self):
        self.graph = {}

    def add_location(self, location):
        self.graph.setdefault(location, {})

    def add_route(self, a, b, distance_km):
        self.add_location(a)
        self.add_location(b)
        self.graph[a][b] = float(distance_km)
        self.graph[b][a] = float(distance_km)


delivery_graph = DeliveryGraph()

# Demonstration road network using recognizable Hyderabad delivery areas.
# Distances are project-network values, not live map distances.
delivery_graph.add_route("Warehouse", "Hafeezpet", 8)
delivery_graph.add_route("Warehouse", "Miyapur", 10)
delivery_graph.add_route("Warehouse", "Kondapur", 15)
delivery_graph.add_route("Warehouse", "Gachibowli", 22)
delivery_graph.add_route("Warehouse", "Madhapur", 20)

delivery_graph.add_route("Hafeezpet", "Miyapur", 5)
delivery_graph.add_route("Hafeezpet", "Kondapur", 9)
delivery_graph.add_route("Hafeezpet", "Madhapur", 14)

delivery_graph.add_route("Miyapur", "Kondapur", 8)
delivery_graph.add_route("Miyapur", "Gachibowli", 17)

delivery_graph.add_route("Kondapur", "Gachibowli", 9)
delivery_graph.add_route("Kondapur", "Madhapur", 7)
delivery_graph.add_route("Gachibowli", "Madhapur", 6)

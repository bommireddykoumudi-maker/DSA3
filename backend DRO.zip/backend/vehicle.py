class Vehicle:
    def __init__(self, vehicle_id, capacity):
        self.vehicle_id = vehicle_id
        self.capacity = float(capacity)
        self.deliveries = []
        self.total_load = 0.0

    def can_accept(self, weight):
        return self.total_load + float(weight) <= self.capacity

    def add_delivery(self, delivery):
        weight = float(delivery["weight"])
        if self.can_accept(weight):
            self.deliveries.append(delivery)
            self.total_load += weight
            return True
        return False


class VehicleAssignment:
    """Capacity-constrained first-fit assignment, with heavier packages first."""

    def __init__(self, vehicles):
        self.vehicles = vehicles

    def assign(self, deliveries):
        unassigned = []
        for delivery in sorted(deliveries, key=lambda d: float(d["weight"]), reverse=True):
            placed = False
            for vehicle in self.vehicles:
                if vehicle.add_delivery(delivery):
                    placed = True
                    break
            if not placed:
                unassigned.append(delivery)
        return unassigned

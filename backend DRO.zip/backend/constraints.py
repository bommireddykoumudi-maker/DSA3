class ConstraintChecker:
    def validate(self, vehicle, route, time_violations):
        capacity_ok = vehicle.total_load <= vehicle.capacity
        route_ok = (
            len(route) >= 2
            and route[0] == "Warehouse"
            and route[-1] == "Warehouse"
        )
        time_window_ok = len(time_violations) == 0
        return {
            "capacity_ok": capacity_ok,
            "route_ok": route_ok,
            "time_window_ok": time_window_ok,
            "feasible": capacity_ok and route_ok and time_window_ok,
        }

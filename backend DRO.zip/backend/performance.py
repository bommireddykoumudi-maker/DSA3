class PerformanceAnalyzer:
    def __init__(self, baseline_distance, optimized_distance):
        self.baseline_distance = float(baseline_distance)
        self.optimized_distance = float(optimized_distance)

    def result(self):
        saved = self.baseline_distance - self.optimized_distance
        improvement = (saved / self.baseline_distance * 100) if self.baseline_distance else 0
        return round(saved, 2), round(improvement, 2)
